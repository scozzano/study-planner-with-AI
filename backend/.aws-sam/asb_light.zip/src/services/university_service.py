from src.repository.university_repository import DynamoUniversityRepository
from src.model.records.university_record import UniversityRecord


class UniversityService():
    def __init__(self, repository: DynamoUniversityRepository):
        self.repository = repository

    def get_university_degree(self, degreeId: str) -> UniversityRecord:
        return self.repository.get_degree(degreeId)