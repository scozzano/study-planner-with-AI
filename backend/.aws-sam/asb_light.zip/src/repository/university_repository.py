import boto3
from src.model.records.university_record import UniversityRecord
from boto3.dynamodb.conditions import Key
from typing import Optional


class DynamoUniversityRepository:
    def __init__(self):
        self.dynamodb = boto3.resource('dynamodb')
        self.table = self.dynamodb.Table('AdaProjectTable')

    def get_degree(self, degreeId: str) -> Optional[UniversityRecord]:
        try:
            response = self.table.get_item(
                Key={
                    'PK': f'UNIVERSITY#',
                    'SK': f'DEGREE#{degreeId}'
                }
            )
            
            item = response.get('Item')
            if item:
                return UniversityRecord(**item)
            return None
            
        except Exception as e:
            print(f"Error getting degree {degreeId}: {e}")
            return None
