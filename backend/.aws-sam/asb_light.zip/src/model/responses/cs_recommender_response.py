from typing import List
from pydantic import BaseModel

class SubjectRecommendation(BaseModel):
    subject: str
    result: float
    rank: int

class CsRecommenderResponse(BaseModel):
    model_version: str
    recommendations: List[SubjectRecommendation]
    degree_year: int