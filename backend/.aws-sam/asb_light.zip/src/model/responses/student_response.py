from pydantic import BaseModel
from typing import List, Optional


class Subject(BaseModel):
    code: str
    name: str
    semester: str
    date: Optional[str] = None
    status: str
    grade: Optional[int] = None
    attempts: Optional[int] = None
    last_attempt_date: Optional[str] = None


class StudentRecord(BaseModel):
    id: str
    name: str
    document: str
    enrollment_number: str
    title: str
    plan: str
    start_date: str
    graduation_date: Optional[str]
    average_grade: Optional[int]
    average_approved_grade: Optional[int]
    subjects_required: int
    subjects_obtained: int
    failed_subjects: int
    subjects: List[Subject]
