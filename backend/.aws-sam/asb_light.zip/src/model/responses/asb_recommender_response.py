from typing import List
from pydantic import BaseModel

class Condition(BaseModel):
    course: str
    grade: str = None
    action: str = None
    target: str = None

class Rules(BaseModel):
    prediction: str
    accuracy: float
    conditions: List[Condition]

class AsbRecommenderResponse(BaseModel):
    rules: List[Rules]
