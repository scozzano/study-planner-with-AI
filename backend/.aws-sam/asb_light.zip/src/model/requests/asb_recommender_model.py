from typing import List
from pydantic import BaseModel

class AsbRecommenderModel(BaseModel):
    course: str
    student_id: int
    label: str
    label_index: int
    is_binary_label: bool
    feature: str
    index_type: str
    is_atomic: bool
    is_pm: bool
    combinations: List[str]
    top_k: int