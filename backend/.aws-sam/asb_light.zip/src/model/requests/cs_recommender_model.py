from typing import List
from pydantic import BaseModel


class CsRecommenderModel(BaseModel):
    student_id: str
    candidate_subjects: List[str]
    degree_year: int