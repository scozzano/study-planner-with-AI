from pydantic import BaseModel
from typing import List


class SubjectType(BaseModel):
    id: str
    name:str
    type: str


class RequirerSubjectRecord(BaseModel):
    id: str
    min: str
    subjects: List[SubjectType]
