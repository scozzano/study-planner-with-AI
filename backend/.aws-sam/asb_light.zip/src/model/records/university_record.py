from pydantic import BaseModel
from typing import List
from src.model.records.university_subject_record import UniversitySubjectRecord


class UniversityRecord(BaseModel):
    id: int
    degree: str
    plan: str
    subjects: List[UniversitySubjectRecord]
