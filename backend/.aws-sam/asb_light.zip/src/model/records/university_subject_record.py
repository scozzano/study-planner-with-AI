from pydantic import BaseModel
from typing import List, Optional


class UniversitySubjectRecord(BaseModel):
    id: Optional[int]
    name: str
    semester: float
    subjectIds: Optional[List[int]]
