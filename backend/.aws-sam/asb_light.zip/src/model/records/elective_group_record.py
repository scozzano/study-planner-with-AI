from pydantic import BaseModel
from typing import List


class ElectiveGroupRecord(BaseModel):
    name: str
    semester: float
    subjectIds: List[int]
