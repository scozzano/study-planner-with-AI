import os
import json
import boto3
import traceback
import sys
from datetime import datetime, timezone
from typing import Dict, Any

# Agregar el path para importar el código ASB
current_dir = os.path.dirname(os.path.abspath(__file__))
recommender_dir = os.path.join(current_dir, '..', '..', 'recommender')
sys.path.insert(0, recommender_dir)

try:
    # Importar directamente desde el archivo
    import importlib.util
    asb_file_path = os.path.join(recommender_dir, 'asb-recommender.py')
    
    if not os.path.exists(asb_file_path):
        raise ImportError(f"ASB file not found at: {asb_file_path}")
    
    spec = importlib.util.spec_from_file_location("asb_recommender", asb_file_path)
    asb_recommender = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(asb_recommender)
    
    # Importar las funciones necesarias
    format_ort_plan = asb_recommender.format_ort_plan
    get_features_label = asb_recommender.get_features_label
    classify = asb_recommender.classify
    add_course_index = asb_recommender.add_course_index
    get_label = asb_recommender.get_label
    get_features = asb_recommender.get_features
    drop_rows = asb_recommender.drop_rows
    
    print(f"Successfully imported ASB functions from: {asb_file_path}")
    
except Exception as e:
    print(f"Error importing ASB code: {e}")
    print(f"Current working directory: {os.getcwd()}")
    print(f"Current file directory: {current_dir}")
    print(f"Recommender directory: {recommender_dir}")
    print(f"ASB file path: {asb_file_path}")
    print(f"ASB file exists: {os.path.exists(asb_file_path) if 'asb_file_path' in locals() else 'N/A'}")
    raise e

def submit_handler_standalone_with_dataframe(df, config):
    """
    Versión modificada de submit_handler_standalone que trabaja directamente con DataFrame
    en lugar de leer desde archivo CSV
    """
    import pandas as pd
    import numpy as np
    
    # Initialize return variables
    score_dict = {}  # evaluation results of 4-fold cross-validation
    DT_names = []  # list of names of different DTs
    figures = []  # list of graphviz objects of trained DTs for each selected feature
    parsed = []  # list of rules (and sorting weights) of each DT
    error_msg = ""  # error message to show in GUI in case of an error

    # Modificar la función get_features_label para trabajar con DataFrame
    def get_features_label_from_dataframe(df, clf_dict):
        """
        Versión modificada de get_features_label que trabaja con DataFrame
        """
        # Usar el DataFrame directamente en lugar de leer CSV
        feature = clf_dict["feature"]
        is_atomic = clf_dict["is_atomic"]
        pm_index_type = clf_dict["index_type"]
        add_course_index(df, feature, is_atomic, pm_index_type)

        label = get_label(df, clf_dict)

        # Check: Do we have less than two classes?
        error_msg = ""
        unique_labels = label["label"].dropna().unique()
        count_labels = label["label"].value_counts()
        num_labels = len(unique_labels)

        if num_labels < 2:
            if num_labels > 0:
                error_msg = (
                    "Classification not helpful:\n\nLabel needs to have more than 1 class. Got "
                    + str(num_labels)
                    + " class instead: "
                    + unique_labels[0]
                    + "\n"
                    + str(count_labels)
                )
            else:
                error_msg = (
                    "Classification not helpful:\n\nLabel needs to have more than 1 class. Got "
                    + str(num_labels)
                    + " class instead."
                )
            return [], [], error_msg

        features = get_features(df, clf_dict)

        # drop rows that don't have a label (for example do not have a grade for course-1 taken in fachsemester 2)
        features, label = drop_rows(features, label)

        n_features = len(features)
        labels = [label] * n_features

        return features, labels, error_msg

    # Obtener features y labels
    features, label, error_msg = get_features_label_from_dataframe(df, config)

    if features != []:
        score_dict, DT_names, figures, parsed, error_msg = classify(
            features, label, config
        )

    return score_dict, DT_names, figures, parsed, error_msg

def lambda_handler(event, context):
    """
    Handler unificado para ASB que obtiene datos de DynamoDB y ejecuta análisis completo
    
    Event structure:
    {
        "degree_id": "2491",
        "table_name": "AdaProjectTable",  # opcional
        "analysis_config": {
            "label": "Course grade",
            "course": "course-1479",
            "is_binary_label": true,
            "max_depth": 5,
            "is_atomic": true,
            "is_pm": false,
            "index_type": "fachsemester",
            "feature": "Course-Semester",
            "label_index": 1,
            "combinations": ["behav"]
        },
        "sample_size": 100,  # opcional
        "output_to_s3": false,  # opcional
        "s3_bucket": "recommendation-data-ort",  # opcional
        "s3_key": "asb_unified_results.json",  # opcional
        "include_data_summary": true,  # opcional - incluir resumen de datos
        "include_raw_data": false,  # opcional - incluir datos raw (solo si sample_size es pequeño)
        "include_analysis": true  # opcional - ejecutar análisis ML
    }
    """
    
    try:
        # Parsear el evento
        degree_id = event.get('degree_id', '2491')
        table_name = event.get('table_name', os.environ.get('TABLE_NAME', 'AdaProjectTable'))
        analysis_config = event.get('analysis_config', {})
        sample_size = event.get('sample_size')
        output_to_s3 = event.get('output_to_s3', False)
        s3_bucket = event.get('s3_bucket', 'recommendation-data-ort')
        s3_key = event.get('s3_key', f'asb_unified_results_{degree_id}_{datetime.now().strftime("%Y%m%d_%H%M%S")}.json')
        include_data_summary = event.get('include_data_summary', True)
        include_raw_data = event.get('include_raw_data', False)
        include_analysis = True  # Siempre ejecutar análisis
        
        print(f"Iniciando análisis ASB unificado para degree_id: {degree_id}")
        print(f"Configuración: {json.dumps(analysis_config, indent=2)}")
        print(f"Incluir análisis: {include_analysis}, Incluir datos raw: {include_raw_data}")
        
        # Paso 1: Obtener y formatear datos desde DynamoDB
        print("Obteniendo datos desde DynamoDB...")
        df = format_ort_plan(
            degree_id=degree_id,
            table_name=table_name,
            output_file=None,  # No guardar CSV
            sample_size=sample_size
        )
        
        if df.empty:
            return {
                'statusCode': 400,
                'body': json.dumps({
                    'error': 'No se encontraron datos',
                    'message': f'No se encontraron datos para degree_id: {degree_id}'
                })
            }
        
        print(f"Datos obtenidos: {df.shape[0]} registros, {df['studentstudyid'].nunique()} estudiantes únicos")
        
        # Paso 2: Preparar resumen de datos
        data_summary = {}
        if include_data_summary:
            data_summary = {
                'total_records': len(df),
                'unique_students': df['studentstudyid'].nunique(),
                'unique_courses': df['Course'].nunique(),
                'semester_range': {
                    'min': int(df['fachsemester'].min()),
                    'max': int(df['fachsemester'].max())
                },
                'grade_range': {
                    'min': float(df['course-grade'].min()),
                    'max': float(df['course-grade'].max())
                },
                'status_distribution': df['Final Course Status'].value_counts().to_dict(),
                'columns': list(df.columns)
            }
        
        # Paso 3: Incluir datos raw si se solicita (solo para muestras pequeñas)
        raw_data = None
        if include_raw_data and sample_size and sample_size <= 100:
            raw_data = df.head(50).to_dict('records')  # Solo primeras 50 filas
        elif include_raw_data and not sample_size and len(df) <= 100:
            raw_data = df.head(50).to_dict('records')
        
        # Paso 4: Ejecutar análisis ML si se solicita
        analysis_results = {}
        if include_analysis and analysis_config:
            print("Ejecutando análisis ASB...")
            
            # Configuración por defecto para ASB
            default_config = {
                "label": "Course grade",
                "course": "course-1479",
                "GPA_grades": "",
                "is_binary_label": True,
                "model": "DT",
                "max_depth": 5,
                "is_atomic": True,
                "is_pm": False,
                "index_type": "fachsemester",
                "feature": "Course-Semester",
                "label_index": 1,
                "combinations": ["behav"]
            }
            
            # Mergear configuración por defecto con la proporcionada
            final_config = {**default_config, **analysis_config}
            
            # Ejecutar análisis
            score_dict, DT_names, figures, parsed, error_msg = submit_handler_standalone_with_dataframe(df, final_config)
            
            if error_msg:
                analysis_results = {
                    'error': error_msg,
                    'config': final_config
                }
            else:
                analysis_results = {
                    'score_dict': score_dict,
                    'DT_names': DT_names,
                    'num_decision_trees': len(figures),
                    'num_rule_sets': len(parsed),
                    'rules': parsed,
                    'config': final_config
                }
        
        # Paso 5: Preparar respuesta unificada
        response = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'degree_id': degree_id,
            'table_name': table_name,
            'sample_size': sample_size,
            'data_summary': data_summary,
            'raw_data': raw_data,
            'analysis_results': analysis_results
        }
        
        # Paso 6: Guardar en S3 si se solicita
        if output_to_s3:
            print(f"Guardando resultados en S3: s3://{s3_bucket}/{s3_key}")
            s3_client = boto3.client('s3')
            s3_client.put_object(
                Bucket=s3_bucket,
                Key=s3_key,
                Body=json.dumps(response, indent=2, ensure_ascii=False),
                ContentType='application/json'
            )
            response['s3_location'] = f's3://{s3_bucket}/{s3_key}'
        
        print("Análisis ASB unificado completado exitosamente")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Análisis ASB unificado completado exitosamente',
                'results': response
            }, ensure_ascii=False)
        }
        
    except Exception as e:
        error_msg = f"Error en análisis ASB unificado: {str(e)}"
        print(error_msg)
        print(traceback.format_exc())
        
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': 'Error interno del servidor',
                'message': error_msg,
                'traceback': traceback.format_exc()
            })
        }

def test_handler():
    """Función de prueba para el handler unificado"""
    
    # Test 1: Solo datos (sin análisis)
    test_event_data_only = {
        "degree_id": "2491",
        "table_name": "AdaProjectTable",
        "sample_size": 50,
        "include_data_summary": True,
        "include_raw_data": True,
        "include_analysis": False,
        "output_to_s3": False
    }
    
    # Test 2: Análisis completo
    test_event_full = {
        "degree_id": "2491",
        "table_name": "AdaProjectTable",
        "analysis_config": {
            "label": "Course grade",
            "course": "course-1479",
            "is_binary_label": True,
            "max_depth": 3,
            "is_atomic": True,
            "is_pm": False,
            "index_type": "fachsemester",
            "feature": "Course-Semester",
            "label_index": 1,
            "combinations": ["behav"]
        },
        "sample_size": 30,
        "include_data_summary": True,
        "include_raw_data": False,
        "include_analysis": True,
        "output_to_s3": False
    }
    
    print("Ejecutando prueba del handler unificado ASB...")
    print("Test 1: Solo datos")
    result1 = lambda_handler(test_event_data_only, None)
    print(f"Resultado 1: {json.dumps(result1, indent=2, ensure_ascii=False)}")
    
    print("\nTest 2: Análisis completo")
    result2 = lambda_handler(test_event_full, None)
    print(f"Resultado 2: {json.dumps(result2, indent=2, ensure_ascii=False)}")

if __name__ == "__main__":
    test_handler()
