import json
import base64
import logging
from src.model.requests.schooling_model import SchoolingRequest
from src.services.student_service import StudentService
from src.repository.students_repository import DynamoStudentsRepository

logger = logging.getLogger()
logger.setLevel(logging.INFO)

students_repository = DynamoStudentsRepository()
students_services = StudentService(students_repository)

CORS_HEADERS = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Headers": "Content-Type",
    "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
}


def lambda_handler(event, context):
    try:
        body = json.loads(event.get("body", "{}"))
        request_data = SchoolingRequest(**body)

        pdf_bytes = base64.b64decode(request_data.file)

        result = students_services.upload_schooling(pdf_bytes)

        return {
            "statusCode": 200,
            "body": json.dumps({
                "message": "La escolaridad fue procesada exitosamente",
                "headers": CORS_HEADERS,
                "summary": result
                })
        }

    except Exception as e:
        logger.error(f"Error al procesar la escolaridad: {str(e)}")
        return {
            "statusCode": 500,
            "headers": CORS_HEADERS,
            "body": json.dumps({"error": f"{str(e)}"})
        }
