#!/usr/bin/env python3
"""
ASB Recommender Light Handler
Versión ligera que usa SageMaker para el análisis en lugar de ejecutar todo en Lambda
"""

import json
import boto3
import os
from datetime import datetime
import logging

# Configurar logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    """
    Handler principal para el endpoint ASB Recommender
    """
    try:
        # Parsear el body de la request
        if isinstance(event.get('body'), str):
            body = json.loads(event['body'])
        else:
            body = event.get('body', {})
        
        # Extraer parámetros
        degree_id = body.get('degree_id', '2491')
        sample_size = body.get('sample_size')
        output_to_s3 = body.get('output_to_s3', False)
        include_data_summary = body.get('include_data_summary', True)
        include_raw_data = body.get('include_raw_data', False)
        
        logger.info(f"Procesando request para degree_id: {degree_id}")
        
        # Obtener datos desde DynamoDB
        formatted_data = get_and_format_data(degree_id, sample_size)
        
        if not formatted_data:
            return {
                'statusCode': 400,
                'headers': {
                    'Content-Type': 'application/json',
                    'Access-Control-Allow-Origin': '*'
                },
                'body': json.dumps({
                    'error': 'No se pudieron obtener datos de DynamoDB',
                    'degree_id': degree_id
                })
            }
        
        # Preparar respuesta
        response_data = {
            'success': True,
            'degree_id': degree_id,
            'timestamp': datetime.now().isoformat(),
            'data_summary': {
                'total_records': len(formatted_data),
                'unique_students': formatted_data['studentstudyid'].nunique(),
                'unique_courses': formatted_data['Course'].nunique(),
                'passed_courses': len(formatted_data[formatted_data['Final Course Status'] == 'PASSED']),
                'failed_courses': len(formatted_data[formatted_data['Final Course Status'] == 'FAILED'])
            }
        }
        
        # Incluir datos raw si se solicita
        if include_raw_data:
            response_data['raw_data'] = formatted_data.to_dict('records')
        
        # Guardar en S3 si se solicita
        if output_to_s3:
            s3_key = save_to_s3(formatted_data, degree_id)
            response_data['s3_output'] = {
                'bucket': os.environ.get('S3_BUCKET'),
                'key': s3_key
            }
        
        # Nota: El análisis ASB se ejecutaría en SageMaker
        # Por ahora solo devolvemos los datos formateados
        response_data['note'] = 'Para análisis ASB completo, usar endpoint de SageMaker'
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps(response_data, default=str)
        }
        
    except Exception as e:
        logger.error(f"Error en lambda_handler: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            },
            'body': json.dumps({
                'error': f'Error interno del servidor: {str(e)}'
            })
        }


def get_and_format_data(degree_id, sample_size=None):
    """
    Obtiene y formatea datos desde DynamoDB
    """
    try:
        # Importar pandas solo cuando sea necesario
        import pandas as pd
        import numpy as np
        
        dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
        table_name = os.environ.get('TABLE_NAME', 'AdaProjectTable')
        table = dynamodb.Table(table_name)
        
        # Query para obtener datos de estudiantes
        pk_value = f"DEGREE#{degree_id}"
        response = table.query(
            KeyConditionExpression=boto3.dynamodb.conditions.Key('PK').eq(pk_value) & 
                                 boto3.dynamodb.conditions.Key('SK').begins_with('STUDENTS#'),
            Limit=1000
        )
        
        items = response.get('Items', [])
        
        if not items:
            logger.warning(f"No se encontraron datos para degree_id: {degree_id}")
            return None
        
        # Convertir a formato ASB
        asb_data = []
        for item in items:
            student_data = item.get('data', {})
            if not student_data:
                continue
                
            student_id = student_data.get('id_codigo')
            if not student_id:
                continue
            
            # Procesar materias del estudiante
            subjects = student_data.get('subjects', [])
            for subject in subjects:
                subject_code = subject.get('ID_MATERIA')
                if not subject_code:
                    continue
                
                # Obtener calificación y estado
                grade = subject.get('CALIFICACION_CTA_CTE_ACD')
                status = subject.get('RESULTADO_CTA_CTE_ACD', '')
                
                # Convertir calificación a GPA
                gpa = convert_grade_to_gpa(grade, status)
                
                # Obtener término
                term = subject.get('NOMBRE_COMIENZO', '')
                
                asb_data.append({
                    'studentstudyid': student_id,
                    'Course': subject_code,
                    'Time-Start': term,
                    'Final Course Status': 'PASSED' if status == 'PASSED' else 'FAILED',
                    'course-grade': gpa
                })
        
        if not asb_data:
            logger.warning("No se pudieron procesar datos de materias")
            return None
        
        # Crear DataFrame
        df = pd.DataFrame(asb_data)
        
        # Filtrar valores None
        df = df.dropna(subset=['course-grade'])
        
        # Aplicar sample si se especifica
        if sample_size and len(df) > sample_size:
            unique_students = df['studentstudyid'].unique()
            if len(unique_students) > sample_size:
                selected_students = np.random.choice(unique_students, sample_size, replace=False)
                df = df[df['studentstudyid'].isin(selected_students)]
        
        logger.info(f"Datos procesados: {len(df)} registros, {df['studentstudyid'].nunique()} estudiantes")
        return df
        
    except Exception as e:
        logger.error(f"Error obteniendo datos: {str(e)}")
        return None


def convert_grade_to_gpa(grade_str, status):
    """
    Convierte calificación de 0-100 a GPA 0-4
    """
    if not grade_str or grade_str == "":
        return None
    
    try:
        grade = float(grade_str)
        if grade < 0 or grade > 100:
            return None
        
        # Convertir a GPA (0-4)
        if grade >= 90:
            return 4.0
        elif grade >= 80:
            return 3.0
        elif grade >= 70:
            return 2.0
        elif grade >= 60:
            return 1.0
        else:
            return 0.0
            
    except (ValueError, TypeError):
        return None


def save_to_s3(dataframe, degree_id):
    """
    Guarda el DataFrame en S3
    """
    try:
        import pandas as pd
        
        s3_client = boto3.client('s3')
        bucket_name = os.environ.get('S3_BUCKET')
        s3_prefix = os.environ.get('S3_PREFIX', 'asb-data')
        
        # Generar nombre del archivo
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"asb_data_{degree_id}_{timestamp}.csv"
        s3_key = f"{s3_prefix}/{filename}"
        
        # Convertir DataFrame a CSV
        csv_buffer = dataframe.to_csv(index=False)
        
        # Subir a S3
        s3_client.put_object(
            Bucket=bucket_name,
            Key=s3_key,
            Body=csv_buffer,
            ContentType='text/csv'
        )
        
        logger.info(f"Datos guardados en S3: s3://{bucket_name}/{s3_key}")
        return s3_key
        
    except Exception as e:
        logger.error(f"Error guardando en S3: {str(e)}")
        raise
