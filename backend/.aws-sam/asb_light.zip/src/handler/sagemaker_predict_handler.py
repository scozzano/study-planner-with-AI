import os
import json
import boto3
import traceback
from datetime import datetime, timezone
from typing import Dict, Any

# Configuración de AWS
sagemaker = boto3.client('sagemaker')
sagemaker_runtime = boto3.client('sagemaker-runtime')
dynamodb = boto3.resource('dynamodb')

# Importar el logger de recomendaciones
import sys
sys.path.append('/opt/python')
try:
    from utils.recommendation_logger import log_recommendation
except ImportError:
    # Para desarrollo local
    import sys
    import os
    sys.path.append(os.path.join(os.path.dirname(__file__), '..'))
    from utils.recommendation_logger import log_recommendation

def get_latest_endpoint(algorithm: str, degree_id: str) -> str:
    """Obtener el endpoint con nombre fijo para un algoritmo"""
    
    try:
        # Usar nombres fijos para los endpoints
        endpoint_name = f"{algorithm}-endpoint"
        
        # Verificar que el endpoint existe y está en servicio
        response = sagemaker.describe_endpoint(EndpointName=endpoint_name)
        
        if response['EndpointStatus'] != 'InService':
            raise ValueError(f"Endpoint {endpoint_name} no está en servicio (estado: {response['EndpointStatus']})")
        
        return endpoint_name
        
    except sagemaker.exceptions.ClientError as e:
        if e.response['Error']['Code'] == 'ValidationException':
            raise ValueError(f"Endpoint {endpoint_name} no existe")
        else:
            raise ValueError(f"Error verificando endpoint: {str(e)}")
    except Exception as e:
        raise ValueError(f"Error obteniendo endpoint: {str(e)}")

def lambda_handler(event, context):
    """Handler principal de Lambda para predicciones SageMaker"""
    
    try:
        # Parsear el request
        body = json.loads(event.get('body', '{}'))
        
        # Validar parámetros requeridos
        algorithm = body.get('algorithm', '').lower()
        if not algorithm:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Parámetro "algorithm" es requerido'})
            }
        
        if algorithm not in ['asb', 'cs', 'pm', 'spm']:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': f'Algoritmo "{algorithm}" no soportado'})
            }
        
        # Obtener el endpoint con nombre fijo
        degree_id = body.get('degree_id', '2491')
        endpoint_name = get_latest_endpoint(algorithm, degree_id)
        
        print(f"🎯 Usando endpoint: {endpoint_name}")
        
        # Preparar datos para predicción
        prediction_data = {
            'algorithm': algorithm,
            **body  # Incluir todos los parámetros del request
        }
        
        # Mapear studentId a student_id para compatibilidad con scripts de inferencia
        if 'studentId' in prediction_data:
            prediction_data['student_id'] = prediction_data['studentId']
        
        # Mapear degreeId a degree_id para compatibilidad
        if 'degreeId' in prediction_data:
            prediction_data['degree_id'] = prediction_data['degreeId']
        
        # Realizar predicción
        response = sagemaker_runtime.invoke_endpoint(
            EndpointName=endpoint_name,
            ContentType='application/json',
            Body=json.dumps(prediction_data)
        )
        
        # Parsear respuesta
        result = json.loads(response['Body'].read().decode())
        
        # Loggear la recomendación en DynamoDB
        try:
            # Extraer student_id del request
            student_id = prediction_data.get('student_id') or prediction_data.get('studentId')
            if student_id:
                print(f"📝 Loggeando recomendación para estudiante: {student_id}")
                log_recommendation(
                    student_id=str(student_id),
                    degree_id=str(degree_id),
                    request_data=prediction_data,
                    response_data=result
                )
            else:
                print("⚠️ No se pudo extraer student_id para logging")
        except Exception as log_error:
            print(f"⚠️ Error en logging (no crítico): {str(log_error)}")
            # No interrumpir el flujo principal por errores de logging
        
        return {
            'statusCode': 200,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps(result)
        }
        
    except Exception as e:
        print(f"❌ Error en predicción: {str(e)}")
        print(f"📋 Traceback: {traceback.format_exc()}")
        
        return {
            'statusCode': 500,
            'headers': {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'POST, OPTIONS'
            },
            'body': json.dumps({
                'error': 'Internal server error',
                'details': str(e)
            })
        }
