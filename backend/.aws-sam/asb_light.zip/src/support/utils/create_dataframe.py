import pandas as pd

from src.repository.students_repository import DynamoStudentsRepository
        
class CreateDataFrame:
    def __init__(self, repository: DynamoStudentsRepository):
        self.repository = repository
        
    def create_dataframe(self):
        data = self.repository.get_all_schooling()
        rows = []
        for rec in data:
            for subj in rec.subjects:
                rows.append({
                    'student_id': rec.id,
                    'subject_id': subj.code,
                    'semestre': subj.semester,
                    'date': subj.date,
                    'status': subj.status,
                    'attempts': subj.attempts,
                    'grade': subj.grade,
                    'result_type': subj.result_type,
                    'result_source': subj.result_source,
                })
        df = pd.DataFrame(
            rows,
            columns=[
                'student_id', 'subject_id', 'semestre', 'date',
                'status', 'attempts', 'grade', 'result_type', 'result_source'
            ]
        )
        df.to_csv('datos/estudiantes.csv', index=False)
        return df